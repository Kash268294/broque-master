import ProductForm from "../../Components/ProductForm";

export default function NewProduct() {
  return (
    <>
      <h1>New Product</h1>
      <ProductForm />
    </>
  );
}