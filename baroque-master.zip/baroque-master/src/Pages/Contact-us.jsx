import React from 'react'

function Contact_us() {
  return (
    <div>Contact-us</div>
  )
}

export default Contact_us