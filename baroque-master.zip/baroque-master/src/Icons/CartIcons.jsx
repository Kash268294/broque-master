export default function CartIcon() {
    return (
        <ion-icon name="bag-outline"></ion-icon>
    );
}